﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.Text;

namespace WCFAddition
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "WCFAddition" in both code and config file together.
    public class WCFAddition : IWCFAddition
    {
        public void DoWork()
        {
        }

        public int SumOfTwoNumber(int num1, int num2)
        {
			string[] lines = { "First line", "Second line", "Third line" };
			return num1 + num2;
		}
	}
}
