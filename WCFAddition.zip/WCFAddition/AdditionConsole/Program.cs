﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdditionConsole
{
	class Program
	{
		static void Main(string[] args)	
		{
			Console.WriteLine("Please enter the first Number");
			int firstNumber = Convert.ToInt32(Console.ReadLine());
			Console.WriteLine("Please enter the second Number");
			int secondNumber = Convert.ToInt32(Console.ReadLine());

			try
			{
				using (NetTcpReference.WCFAdditionClient client = new NetTcpReference.WCFAdditionClient())
				{
					Console.WriteLine("The sum of two number is = " + client.SumOfTwoNumber(firstNumber, secondNumber));
					Console.ReadLine();
				}
			}
			catch(Exception ex)
			{
				Console.Write("The following error occoured: " + ex.Message);
			}
		}
	}
}
